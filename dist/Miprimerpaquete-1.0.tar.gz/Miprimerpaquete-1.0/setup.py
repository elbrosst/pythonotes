from setuptools import setup
setup(

    name = "Miprimerpaquete",
    version = "1.0",
    description = "Es un simple paquete",
    author = "Hector",
    author_email = "ttrox1600@gmaill.com",
    url = "",
    package = ["apaquete","apaquete.paquete1"]


)